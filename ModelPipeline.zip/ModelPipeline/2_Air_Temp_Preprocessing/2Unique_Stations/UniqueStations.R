#--------------------------------------------
# Compile Unique Weather Station Coordinates
#--------------------------------------------

library(dplyr)
library(readr)

# Set this to the folder path that has your MADIS monthly observation .csv files
parent_dir <- 

# Find all CSV files recursively (in all subfolders)
csv_files <- list.files(parent_dir, pattern = "\\.csv$", full.names = TRUE, recursive = TRUE)

# Read and combine all CSVs
all_data <- lapply(csv_files, function(file) {
  read_csv(file, show_col_types = FALSE)
}) %>%
  bind_rows()

# Remove duplicates by STATIONID, LAT, and LON
unique_stations <- all_data %>%
  distinct(station_id, latitude, longitude, .keep_all = TRUE)

output_file <- file.path(parent_dir, "Unique_Stations.csv")
write_csv(unique_stations, output_file)

